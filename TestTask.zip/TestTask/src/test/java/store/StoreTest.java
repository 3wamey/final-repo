package store;

import org.example.account.AccountManager;
import org.example.account.Customer;
import org.example.store.Product;
import org.example.store.Store;
import org.example.store.StoreImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;


public class StoreTest{
    @Test
    public void givenProductWithInsufficientQuantity_whenBuy_thenNoChange() {
        // Arrange
        Product product = new Product();
        product.setPrice(100);
        product.setQuantity(0);

        Customer customer = new Customer();
        customer.setBalance(200);

        AccountManager accountManager = mock(AccountManager.class);


        Store store = new StoreImpl(accountManager);

        // Act
        store.buy(product, customer);

        // Assert
        Assertions.assertEquals(0, product.getQuantity());
        verify(accountManager, never()).withdraw(any(Customer.class), anyInt());
    }

    @Test
    public void givenProductWithPositiveQuantityAndCustomerWithInsufficientBalance_whenBuy_thenNoChange() {
        // Arrange
        Product product = new Product();
        product.setPrice(100);
        product.setQuantity(4);

        Customer customer = new Customer();
        customer.setBalance(50);

        AccountManager accountManager = mock(AccountManager.class);
        when(accountManager.withdraw(customer, 100)).thenReturn("insufficient account balance");

        Store store = new StoreImpl(accountManager);

        // Act
        store.buy(product, customer);

        // Assert
        Assertions.assertEquals(4, product.getQuantity());
        verify(accountManager, never()).withdraw(any(Customer.class), anyInt());
    }

    @Test
    public void givenProductWithNegativeQuantity_whenBuy_thenNoChange() {
        // Arrange
        Product product = new Product();
        product.setPrice(100);
        product.setQuantity(-1);

        Customer customer = new Customer();
        customer.setBalance(200);

        AccountManager accountManager = mock(AccountManager.class);

        Store store = new StoreImpl(accountManager);

        // Act
        store.buy(product, customer);

        // Assert
        Assertions.assertEquals(-1, product.getQuantity());
        verify(accountManager, never()).withdraw(any(Customer.class), anyInt());
    }
}