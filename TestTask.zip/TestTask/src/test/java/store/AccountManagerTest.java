package store;

import org.example.account.AccountManager;
import org.example.account.AccountManagerImpl;
import org.example.account.Customer;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class AccountManagerTest {
    @Test
    public void givenPositiveCustomerBalanceWithAmount_whenDeposit_thenGetBalanceAfterAddingAmount(){
        //Arrange
        AccountManager accountManager = new AccountManagerImpl();
        Customer customer = new Customer();
        customer.setBalance(100);
        int amount = 200;
        //Act
        accountManager.deposit(customer,amount);
        //Assert
        Assertions.assertEquals(300,customer.getBalance());
    }

    @Test
    public void givenPositiveCustomerBalanceWithAmount_whenWithdraw_thenReturnSuccess(){
        //Arrange
        AccountManager accountManager = new AccountManagerImpl();
        Customer customer = new Customer();
        customer.setBalance(500);
        int amount = 300;
        //Act
        accountManager.withdraw(customer,amount);
        //Assert
        Assertions.assertEquals(200,customer.getBalance());
    }
    @Test
    public void givenPositiveCustomerBalanceWithTrueVipWithTrueCreditAllowedWithLargeAmount_whenWithdraw_thenSuccess(){
        //Arrange
        AccountManager accountManager = new AccountManagerImpl();
        Customer customer = new Customer();
        customer.setBalance(500);
        customer.setVip(true);
        customer.setCreditAllowed(true);
        int amount = 1800;
        //Act
        String result = accountManager.withdraw(customer,amount);
        //Assert
        Assertions.assertEquals("success", result);
    }

    @Test
    public void givenPositiveCustomerBalanceWithFalseCreditAllowedWithLargeAmount_whenWithdraw_thenInsufficientAccountBalance(){
        //Arrange
        AccountManager accountManager = new AccountManagerImpl();
        Customer customer = new Customer();
        customer.setBalance(500);
        customer.setCreditAllowed(false);
        int amount = 600;
        //Act
        String result = accountManager.withdraw(customer,amount);
        //Assert
        Assertions.assertEquals("insufficient account balance", result);
    }

    @Test
    public void givenPositiveCustomerBalanceWithFalseVipWithTrueCreditAllowedWithLargeAmount_whenWithdraw_thenMaximumCreditExceeded(){
        //Arrange
        AccountManager accountManager = new AccountManagerImpl();
        Customer customer = new Customer();
        customer.setBalance(500);
        customer.setVip(false);
        customer.setCreditAllowed(true);
        int amount = 1800;
        //Act
        String result = accountManager.withdraw(customer,amount);
        //Assert
        Assertions.assertEquals("maximum credit exceeded", result);
    }
}
