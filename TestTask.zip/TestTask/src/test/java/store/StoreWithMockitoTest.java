package store;

import org.example.account.AccountManager;
import org.example.account.Customer;
import org.example.store.Product;
import org.example.store.Store;
import org.example.store.StoreImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;

public class StoreWithMockitoTest {

    @Test
    public void givenProductWithPositiveQuantityAndCustomerWithSufficientBalance_whenBuy_thenSuccess() {
        // Arrange
        Product product = new Product();
        product.setPrice(100);
        product.setQuantity(4);
        Customer customer = new Customer();
        AccountManager accountManager = mock(AccountManager.class);
        when(accountManager.withdraw(customer, product.getPrice()))
                .thenReturn("success");
        Store store = new StoreImpl(accountManager);
        // Act
        store.buy(product, customer);
        // Assert
        Assertions.assertEquals(3, product.getQuantity());
        verify(accountManager).withdraw(customer, 100);
    }

    @Test
    public void givenProductWithZeroQuantityAndCustomer_whenBuy_thenExceptionProductOutOfStock() {
        // Arrange
        Product product = new Product();
        product.setPrice(100);
        product.setQuantity(0);
        Customer customer = new Customer();
        AccountManager accountManager = mock(AccountManager.class);
        Store store = new StoreImpl(accountManager);
        // Act
        RuntimeException runtimeException = Assertions.assertThrows(RuntimeException.class, () -> store.buy(product, customer));
        // Assert
        Assertions.assertEquals("Product out of stock", runtimeException.getMessage());
    }
    @Test
    public void givenProductWithPositiveQuantityAndCustomerWithSufficient_whenBuy_thenExceptionPaymentFailure(){
        // Arrange
        Product product = new Product();
        product.setPrice(100);
        product.setQuantity(3);
        Customer customer = new Customer();
        customer.setBalance(20);
        AccountManager accountManager = mock(AccountManager.class);
        when(accountManager.withdraw(customer,product.getPrice())).thenReturn("not success");
        Store store = new StoreImpl(accountManager);
        // Act
        RuntimeException runtimeException = Assertions.assertThrows(RuntimeException.class, () -> store.buy(product, customer));
        // Assert
        Assertions.assertEquals("Payment failure: not success", runtimeException.getMessage());
    }

}
