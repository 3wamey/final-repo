package example.devices;

public interface DeviceObserver {
    void update(String message);

}
