package example.notifications;

public interface SMSNotifier {

        void sendSMS(String message);

}
