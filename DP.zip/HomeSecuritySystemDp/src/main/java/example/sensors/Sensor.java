package example.sensors;

public interface Sensor {
    void detect();
}
