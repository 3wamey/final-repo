package example.commands;

public class TurnOffAlarmCommand implements Command {
    @java.lang.Override
    public void execute() {

    }
//    @Override
//    public void execute() {
//        System.out.println("Alarm turned off.");
//
//    }
}
