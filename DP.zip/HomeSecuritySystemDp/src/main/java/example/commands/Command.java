package example.commands;

public interface Command {
    void execute();
}
